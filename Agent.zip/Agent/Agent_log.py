import os
import re
import json
import logging
from datetime import datetime
from typing import TypedDict, List, Optional, Dict, Any

import psycopg2
import psycopg2.extras
from dotenv import load_dotenv
from langgraph.graph import StateGraph, END
from langchain_openai import ChatOpenAI
from FlagEmbedding import BGEM3FlagModel

# ---------------------------
# Logging
# ---------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
)
logger = logging.getLogger(__name__)

# ---------------------------
# Config
# ---------------------------
load_dotenv()

LMSTUDIO_BASE_URL = os.getenv("LMSTUDIO_BASE_URL", "http://localhost:1234/v1")
LMSTUDIO_MODEL = os.getenv("LMSTUDIO_MODEL", "gemma-3n-e4b")

PG_HOST = os.getenv("PG_HOST", "localhost")
PG_PORT = int(os.getenv("PG_PORT", "5432"))
PG_USER = os.getenv("PG_USER", "postgres")
PG_PASS = os.getenv("PG_PASS", "postgres")
PG_DB   = os.getenv("PG_DB", "demo_db")

# ---------------------------
# LLM (LM Studio – OpenAI-compatible)
# ---------------------------
llm = ChatOpenAI(
    base_url=LMSTUDIO_BASE_URL,
    api_key="lm-studio",
    model=LMSTUDIO_MODEL,
    temperature=0.2,
    timeout=60,
)

# ---------------------------
# Embedding model – BGE-M3 (1024-dim)
# ---------------------------
logger.info("Loading BGE-M3 embedding model …")
embedding_model = BGEM3FlagModel("BAAI/bge-m3", use_fp16=True)
logger.info("BGE-M3 ready.")

# ---------------------------
# PostgreSQL helpers (pgvector)
# ---------------------------
def get_pg_connection():
    """Return a new psycopg2 connection to the pgvector database."""
    return psycopg2.connect(
        host=PG_HOST,
        port=PG_PORT,
        user=PG_USER,
        password=PG_PASS,
        database=PG_DB,
    )


def test_pg_connection() -> bool:
    """Quick connectivity & table check."""
    try:
        conn = get_pg_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT EXISTS ("
            "  SELECT 1 FROM information_schema.tables "
            "  WHERE table_name = 'dapchatbot'"
            ")"
        )
        exists = cur.fetchone()[0]
        cur.close()
        conn.close()
        if exists:
            logger.info("✅ PostgreSQL connected – table 'dapchatbot' found.")
        else:
            logger.warning(
                "⚠️  PostgreSQL connected but table 'dapchatbot' does NOT exist. "
                "Run embeddings/embedd.py first."
            )
        return exists
    except Exception as exc:
        logger.error("❌ PostgreSQL connection failed: %s", exc)
        return False


# Simple document wrapper so existing node code can use .page_content / .metadata
class Document:
    """Lightweight document object compatible with LangChain conventions."""
    def __init__(self, page_content: str, metadata: Optional[Dict[str, Any]] = None):
        self.page_content = page_content
        self.metadata = metadata or {}

    def __repr__(self):
        snippet = self.page_content[:80].replace("\n", " ")
        return f"Document('{snippet}…')"


def pgvector_search(query: str, k: int = 4) -> List[Document]:
    """
    Embed *query* with BGE-M3 and run cosine-similarity search
    against the `dapchatbot` table via pgvector.

    Returns a list of Document objects.
    """
    # 1. Encode query
    query_embedding = embedding_model.encode([query])["dense_vecs"][0].tolist()

    # 2. Query PostgreSQL
    conn = get_pg_connection()
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute(
        """
        SELECT question,
               answer,
               1 - (embedding <=> %s::vector) AS similarity
        FROM   dapchatbot
        ORDER  BY embedding <=> %s::vector
        LIMIT  %s
        """,
        (str(query_embedding), str(query_embedding), k),
    )
    rows = cur.fetchall()
    cur.close()
    conn.close()

    # 3. Build documents
    docs: List[Document] = []
    for row in rows:
        content = (
            f"Câu hỏi: {row['question']}\n"
            f"Trả lời: {row['answer']}"
        )
        docs.append(
            Document(
                page_content=content,
                metadata={
                    "question": row["question"],
                    "answer": row["answer"],
                    "similarity": float(row["similarity"]),
                },
            )
        )

    logger.info(
        "🔍 pgvector search returned %d docs (top sim=%.4f)",
        len(docs),
        docs[0].metadata["similarity"] if docs else 0.0,
    )
    return docs


# ---------------------------
# State
# ---------------------------
class AgentState(TypedDict):
    question: str
    intent: Optional[str]
    entities: Optional[List[str]]
    docs: Optional[list]
    rewritten_query: Optional[str]
    relevance: Optional[str]
    topic: Optional[str]
    evidence: Optional[List[str]]
    answer: Optional[str]
    verification: Optional[str]


# ---------------------------
# Helpers
# ---------------------------
def safe_json_loads(text: str, default: Dict[str, Any]) -> Dict[str, Any]:
    """Try to extract a JSON object from LLM output (handles markdown fences)."""
    cleaned = text.strip()
    # Strip ```json ... ``` fences
    fence_match = re.search(r"```(?:json)?\s*(.*?)```", cleaned, re.DOTALL)
    if fence_match:
        cleaned = fence_match.group(1).strip()
    try:
        data = json.loads(cleaned)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return default


def _docs_context(state: AgentState) -> str:
    """Concatenate page_content of all docs in state."""
    docs = state.get("docs") or []
    return "\n\n".join(d.page_content for d in docs)


# ---------------------------
# Nodes
# ---------------------------
def intent_router(state: AgentState) -> AgentState:
    prompt = (
        "You are an intent classifier for a Vietnamese legal assistant.\n"
        "Classify the user's question into EXACTLY ONE of these intents:\n\n"
        "  1. greeting\n"
        "     The user is just saying hello, goodbye, or making small talk.\n"
        "     Examples: 'Xin chào', 'Hi', 'Cảm ơn', 'Tạm biệt'\n\n"
        "  2. direct_system_info\n"
        "     The user asks for current date/time or personal bot information.\n"
        "     Examples: 'Bây giờ mấy giờ?', 'Hôm nay ngày bao nhiêu?', 'Bạn là ai?'\n\n"
        "  3. direct_answer\n"
        "     A simple, short factual question that can be answered with a quick\n"
        "     database lookup (RAG). The question is broad or generic, does NOT\n"
        "     require multi-step reasoning, cross-referencing, or deep analysis.\n"
        "     Examples: 'Hợp đồng lao động là gì?',\n"
        "              'Quyền của người tiêu dùng theo pháp luật Việt Nam?',\n"
        "              'Thời hiệu khởi kiện vụ án dân sự là bao lâu?'\n\n"
        "  4. knowledge_query\n"
        "     A detailed, complex, or specific question that truly requires\n"
        "     in-depth research: query rewriting, evidence gathering, verification,\n"
        "     cross-referencing multiple sources, or multi-step legal reasoning.\n"
        "     Examples: 'So sánh quy định xử phạt hành chính giữa Nghị định 15\n"
        "               và Nghị định 117 về vi phạm an toàn thực phẩm',\n"
        "              'Phân tích điều kiện thành lập doanh nghiệp theo Luật\n"
        "               Doanh nghiệp 2020 so với Luật Doanh nghiệp 2014',\n"
        "              'Trình tự thủ tục giải quyết tranh chấp đất đai qua\n"
        "               các cấp tòa án theo Bộ luật Tố tụng dân sự 2015'\n\n"
        "Also extract any named entities (people, laws, organizations…).\n"
        "Return ONLY a JSON object with keys: intent, entities.\n\n"
        f"Question: {state['question']}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(
        resp.content,
        {"intent": "knowledge_query", "entities": []},
    )
    intent = data.get("intent", "knowledge_query")
    if intent not in ("greeting", "direct_system_info", "direct_answer", "knowledge_query"):
        intent = "knowledge_query"
    data["intent"] = intent
    logger.info("🧭 Intent: %s | Entities: %s", data["intent"], data.get("entities"))
    return {**state, **data}


def system_info_node(state: AgentState) -> AgentState:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    answer = f"Bây giờ là {now}. Tôi có thể giúp gì thêm cho bạn?"
    return {**state, "answer": answer}


def query_rewriter(state: AgentState) -> AgentState:
    prompt = (
        "Rewrite the following question into a concise Vietnamese search query "
        "suitable for semantic retrieval.  Return ONLY JSON: "
        '{{"rewritten_query": "..."}}\n\n'
        f"Question: {state['question']}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"rewritten_query": state["question"]})
    logger.info("✏️  Rewritten query: %s", data.get("rewritten_query"))
    return {**state, **data}


def rag_lookup(state: AgentState) -> AgentState:
    """Retrieve relevant docs from PostgreSQL via pgvector."""
    query = state.get("rewritten_query") or state["question"]
    docs = pgvector_search(query, k=4)
    return {**state, "docs": docs}


def relevance_judge(state: AgentState) -> AgentState:
    context = _docs_context(state)
    prompt = (
        "Judge whether the retrieved context is relevant to the question.\n"
        'Return ONLY JSON: {"relevance": "high"} or {"relevance": "low"}.\n\n'
        f"Question: {state['question']}\n\nContext:\n{context}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"relevance": "low"})
    logger.info("📊 Relevance: %s", data.get("relevance"))
    return {**state, **data}


def web_search_node(state: AgentState) -> AgentState:
    """Placeholder – wire up a real web-search API here."""
    logger.info("🌐 Web search (placeholder – skipped)")
    return {**state, "docs": state.get("docs", [])}


def rag_merge(state: AgentState) -> AgentState:
    """Merge web + RAG results (placeholder)."""
    return state


def topic_judge(state: AgentState) -> AgentState:
    prompt = (
        "Classify the topic of this question.\n"
        'Return ONLY JSON: {"topic": "legal"} if it is about Vietnamese law, '
        'or {"topic": "other"} otherwise.\n\n'
        f"Question: {state['question']}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"topic": "other"})
    logger.info("📂 Topic: %s", data.get("topic"))
    return {**state, **data}


def answer_draft(state: AgentState) -> AgentState:
    context = _docs_context(state)
    prompt = (
        "Bạn là trợ lý pháp luật Việt Nam. Dựa vào ngữ cảnh được cung cấp, "
        "hãy trả lời câu hỏi một cách ngắn gọn, chính xác bằng tiếng Việt.\n"
        "Nếu ngữ cảnh không đủ, hãy nói rõ rằng bạn không có đủ thông tin.\n\n"
        f"Ngữ cảnh:\n{context}\n\n"
        f"Câu hỏi: {state['question']}"
    )
    resp = llm.invoke(prompt)
    return {**state, "answer": resp.content}


def answer_verifier(state: AgentState) -> AgentState:
    prompt = (
        "Verify whether the answer below is strong, well-supported and accurate.\n"
        'Return ONLY JSON: {"verification": "good"} or {"verification": "weak"}.\n\n'
        f"Question: {state['question']}\nAnswer: {state.get('answer')}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"verification": "weak"})
    logger.info("✅ Verification: %s", data.get("verification"))
    return {**state, **data}


def clarify_question(state: AgentState) -> AgentState:
    return {
        **state,
        "answer": "Xin lỗi, tôi chưa chắc chắn về câu trả lời. "
                  "Bạn có thể làm rõ câu hỏi thêm được không?",
    }


def answer_node(state: AgentState) -> AgentState:
    if state.get("answer"):
        return state
    return answer_draft(state)


def greeting_node(state: AgentState) -> AgentState:
    return {**state, "answer": "Xin chào! 👋 Tôi có thể giúp gì cho bạn?"}


def direct_answer_node(state: AgentState) -> AgentState:
    """Simple RAG-based answer: retrieve docs and respond directly."""
    query = state.get("rewritten_query") or state["question"]
    docs = pgvector_search(query, k=4)
    context = "\n\n".join(d.page_content for d in docs)
    prompt = (
        "Bạn là trợ lý thông minh. Dựa vào ngữ cảnh được cung cấp, "
        "hãy trả lời câu hỏi một cách ngắn gọn, chính xác bằng tiếng Việt.\n"
        "Nếu ngữ cảnh không đủ, hãy nói rõ rằng bạn không có đủ thông tin.\n\n"
        f"Ngữ cảnh:\n{context}\n\n"
        f"Câu hỏi: {state['question']}"
    )
    resp = llm.invoke(prompt)
    logger.info("⚡ Direct answer generated (skipped deep pipeline)")
    return {**state, "docs": docs, "answer": resp.content}


def direct_query_rewriter(state: AgentState) -> AgentState:
    """Lightweight query rewriter for the direct_answer path."""
    prompt = (
        "Viết lại câu hỏi sau thành một truy vấn tìm kiếm ngắn gọn bằng tiếng Việt, "
        "tối ưu cho việc tìm kiếm semantic trong cơ sở dữ liệu pháp luật.\n"
        "Giữ nguyên các thuật ngữ pháp lý quan trọng. "
        'Trả về CHỈ JSON: {{"rewritten_query": "..."}}\n\n'
        f"Câu hỏi: {state['question']}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"rewritten_query": state["question"]})
    logger.info("✏️  Direct rewritten query: %s", data.get("rewritten_query"))
    return {**state, **data}


# ---------------------------
# Evidence Subgraph (for legal/pesticide deep-dive)
# ---------------------------
def search_planner(state: AgentState) -> AgentState:
    prompt = (
        "Plan a short retrieval strategy for answering this legal question.\n"
        'Return ONLY JSON: {"plan": ["step1", "step2", ...]}.\n\n'
        f"Question: {state['question']}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"plan": []})
    return {**state, **data}


def multi_source_retrieval(state: AgentState) -> AgentState:
    """Re-retrieve from pgvector if docs are missing."""
    if not state.get("docs"):
        docs = pgvector_search(state["question"], k=6)
        return {**state, "docs": docs}
    return state


def source_ranker(state: AgentState) -> AgentState:
    """Sort docs by similarity (already sorted from pgvector, kept as hook)."""
    docs = state.get("docs") or []
    docs.sort(
        key=lambda d: d.metadata.get("similarity", 0),
        reverse=True,
    )
    return {**state, "docs": docs}


def evidence_extractor(state: AgentState) -> AgentState:
    context = _docs_context(state)
    prompt = (
        "Extract the key evidence snippets from the context below.\n"
        'Return ONLY JSON: {"evidence": ["snippet1", "snippet2", ...]}.\n\n'
        f"Context:\n{context}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"evidence": []})
    return {**state, **data}


def claim_verifier(state: AgentState) -> AgentState:
    prompt = (
        "Verify the claims based on the provided evidence.\n"
        'Return ONLY JSON: {"verification": "good"} or {"verification": "weak"}.\n\n'
        f"Evidence: {state.get('evidence')}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"verification": "weak"})
    return {**state, **data}


def conclusion_builder(state: AgentState) -> AgentState:
    evidence = "\n".join(state.get("evidence") or [])
    prompt = (
        "Bạn là trợ lý pháp luật. Hãy tổng hợp bằng chứng và đưa ra kết luận "
        "cho câu hỏi dưới đây bằng tiếng Việt.\n\n"
        f"Bằng chứng:\n{evidence}\n\n"
        f"Câu hỏi: {state['question']}"
    )
    resp = llm.invoke(prompt)
    return {**state, "answer": resp.content}


# ---------------------------
# Routing functions
# ---------------------------
def route_intent(state: AgentState):
    return state.get("intent", "knowledge_query")


def route_relevance(state: AgentState):
    return state.get("relevance", "low")


def route_topic(state: AgentState):
    return state.get("topic", "other")


def route_verification(state: AgentState):
    return state.get("verification", "weak")


# ---------------------------
# Build LangGraph
# ---------------------------
graph = StateGraph(AgentState)

# --- Nodes ---
graph.add_node("router",           intent_router)
graph.add_node("system_info",      system_info_node)
graph.add_node("query_rewriter",   query_rewriter)
graph.add_node("rag",              rag_lookup)
graph.add_node("relevance_judge",  relevance_judge)
graph.add_node("web_search",       web_search_node)
graph.add_node("rag_merge",        rag_merge)
graph.add_node("topic_judge",      topic_judge)
graph.add_node("answer_draft",     answer_draft)
graph.add_node("answer_verifier",  answer_verifier)
graph.add_node("clarify_question", clarify_question)
graph.add_node("answer",           answer_node)
graph.add_node("greeting",         greeting_node)
graph.add_node("direct_answer",    direct_answer_node)
graph.add_node("direct_query_rewriter", direct_query_rewriter)

# Evidence subgraph nodes
graph.add_node("search_planner",          search_planner)
graph.add_node("multi_source_retrieval",  multi_source_retrieval)
graph.add_node("source_ranker",           source_ranker)
graph.add_node("evidence_extractor",      evidence_extractor)
graph.add_node("claim_verifier",          claim_verifier)
graph.add_node("conclusion_builder",      conclusion_builder)

# --- Entry ---
graph.set_entry_point("router")

# --- Edges ---
graph.add_conditional_edges("router", route_intent, {
    "greeting":           "greeting",
    "direct_system_info": "system_info",
    "direct_answer":      "direct_query_rewriter",
    "knowledge_query":    "query_rewriter",
})

graph.add_edge("system_info",    "answer")
graph.add_edge("query_rewriter", "rag")
graph.add_edge("rag",            "relevance_judge")

graph.add_conditional_edges("relevance_judge", route_relevance, {
    "low":  "web_search",
    "high": "topic_judge",
})

graph.add_edge("web_search", "rag_merge")
graph.add_edge("rag_merge",  "topic_judge")

graph.add_conditional_edges("topic_judge", route_topic, {
    "legal": "search_planner",
    "other": "answer_draft",
})

# Evidence subgraph edges
graph.add_edge("search_planner",         "multi_source_retrieval")
graph.add_edge("multi_source_retrieval",  "source_ranker")
graph.add_edge("source_ranker",           "evidence_extractor")
graph.add_edge("evidence_extractor",      "claim_verifier")
graph.add_edge("claim_verifier",          "conclusion_builder")
graph.add_edge("conclusion_builder",      "answer_verifier")

graph.add_edge("answer_draft", "answer_verifier")

graph.add_conditional_edges("answer_verifier", route_verification, {
    "weak": "clarify_question",
    "good": "answer",
})

graph.add_edge("clarify_question", END)
graph.add_edge("greeting",        END)
graph.add_edge("direct_query_rewriter", "direct_answer")
graph.add_edge("direct_answer",   END)
graph.add_edge("answer",          END)

# --- Compile ---
app = graph.compile()

# ---------------------------
# Interactive run loop
# ---------------------------
if __name__ == "__main__":
    print("=" * 60)
    print("  LangGraph Agent  –  LM Studio + pgvector RAG")
    print("  DB: PostgreSQL @ %s:%s/%s" % (PG_HOST, PG_PORT, PG_DB))
    print("  LLM: %s @ %s" % (LMSTUDIO_MODEL, LMSTUDIO_BASE_URL))
    print("=" * 60)

    # Pre-flight check
    if not test_pg_connection():
        print(
            "\n⚠️  Could not verify the 'dapchatbot' table.\n"
            "    Make sure Docker is running (docker compose up -d)\n"
            "    and embeddings/embedd.py has been executed.\n"
        )

    print("\nType your question (or 'exit' to quit):\n")

    while True:
        try:
            q = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not q or q.lower() in ("exit", "quit"):
            break

        try:
            out = app.invoke({"question": q})
            print("\nAgent:", out.get("answer", "(no answer)"), "\n")
        except Exception as exc:
            logger.error("Error during invoke: %s", exc, exc_info=True)
            print(f"\n❌ Error: {exc}\n")
