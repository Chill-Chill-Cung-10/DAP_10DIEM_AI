import os
import re
import json
import unicodedata
from datetime import datetime
from typing import TypedDict, List, Optional, Dict, Any

import hashlib
from functools import lru_cache

import psycopg2
import psycopg2.extras
import psycopg2.pool
from dotenv import load_dotenv
from langgraph.graph import StateGraph, END
from langchain_openai import ChatOpenAI
from FlagEmbedding import BGEM3FlagModel

# ---------------------------
# Config
# ---------------------------
load_dotenv()

LMSTUDIO_BASE_URL = os.getenv("LMSTUDIO_BASE_URL", "http://localhost:1234/v1")
LMSTUDIO_MODEL = os.getenv("LMSTUDIO_MODEL", "gemma-3n-e4b")

PG_HOST = os.getenv("PG_HOST", "localhost")
PG_PORT = int(os.getenv("PG_PORT", "5432"))
PG_USER = os.getenv("PG_USER", "postgres")
PG_PASS = os.getenv("PG_PASS", "postgres")
PG_DB   = os.getenv("PG_DB", "demo_db")

# ---------------------------
# LLM (LM Studio – OpenAI-compatible)
# ---------------------------
llm = ChatOpenAI(
    base_url=LMSTUDIO_BASE_URL,
    api_key="lm-studio",
    model=LMSTUDIO_MODEL,
    temperature=0.2,
    timeout=60,
)

# ---------------------------
# Embedding model – BGE-M3 (1024-dim)
# ---------------------------
embedding_model = BGEM3FlagModel("BAAI/bge-m3", use_fp16=True)

# ---------------------------
# PostgreSQL connection pool (lazy init – không crash khi import)
# ---------------------------
_pg_pool: Optional[psycopg2.pool.ThreadedConnectionPool] = None


def _ensure_pool():
    """Tạo pool lần đầu khi thực sự cần, tránh crash lúc import."""
    global _pg_pool
    if _pg_pool is None or _pg_pool.closed:
        _pg_pool = psycopg2.pool.ThreadedConnectionPool(
            minconn=2,
            maxconn=10,
            host=PG_HOST,
            port=PG_PORT,
            user=PG_USER,
            password=PG_PASS,
            database=PG_DB,
        )


def get_pg_connection():
    """Return a pooled psycopg2 connection."""
    _ensure_pool()
    return _pg_pool.getconn()


def put_pg_connection(conn):
    """Return a connection back to the pool."""
    if _pg_pool and not _pg_pool.closed:
        _pg_pool.putconn(conn)


def test_pg_connection() -> bool:
    """Quick connectivity & table check.  Also ensures HNSW index + pg_trgm exist."""
    conn = None
    try:
        conn = get_pg_connection()
        cur = conn.cursor()

        # Ensure pg_trgm extension
        cur.execute("CREATE EXTENSION IF NOT EXISTS pg_trgm")
        conn.commit()

        cur.execute(
            "SELECT EXISTS ("
            "  SELECT 1 FROM information_schema.tables "
            "  WHERE table_name = 'dapchatbot'"
            ")"
        )
        exists = cur.fetchone()[0]
        if exists:
            # Kiểm tra HNSW index
            cur.execute(
                "SELECT indexname FROM pg_indexes "
                "WHERE tablename = 'dapchatbot' AND indexdef LIKE '%%hnsw%%'"
            )
            need_index = cur.fetchone() is None
            cur.close()
            # Đóng transaction hiện tại trước khi set autocommit
            conn.commit()
            if need_index:
                conn.autocommit = True
                idx_cur = conn.cursor()
                try:
                    idx_cur.execute(
                        "CREATE INDEX CONCURRENTLY IF NOT EXISTS "
                        "idx_dapchatbot_embedding_hnsw "
                        "ON dapchatbot USING hnsw (embedding vector_cosine_ops) "
                        "WITH (m = 16, ef_construction = 64)"
                    )
                except Exception:
                    pass  # Index fail không ảnh hưởng hoạt động
                finally:
                    idx_cur.close()
                    conn.autocommit = False
        else:
            cur.close()
        return exists
    except Exception:
        return False
    finally:
        if conn:
            put_pg_connection(conn)


class Document:
    """Lightweight document object compatible with LangChain conventions."""
    def __init__(self, page_content: str, metadata: Optional[Dict[str, Any]] = None):
        self.page_content = page_content
        self.metadata = metadata or {}


# ---------------------------
# Embedding cache (tránh encode lại câu giống nhau)
# ---------------------------
_embedding_cache: Dict[str, list] = {}


def _get_embedding(text: str) -> list:
    """Return embedding vector, có cache."""
    key = hashlib.md5(text.encode()).hexdigest()
    if key not in _embedding_cache:
        _embedding_cache[key] = (
            embedding_model.encode([text])["dense_vecs"][0].tolist()
        )
        # Giữ cache không quá lớn
        if len(_embedding_cache) > 200:
            oldest = next(iter(_embedding_cache))
            del _embedding_cache[oldest]
    return _embedding_cache[key]


def pgvector_search(
    query: str,
    k: int = 15,
    similarity_threshold: float = 0.45,
) -> List[Document]:
    """
    Embed *query* with BGE-M3 and run cosine-similarity search
    against the `dapchatbot` table via pgvector.

    Trả về TẤT CẢ các câu có similarity >= threshold (tối đa k).
    """
    query_embedding = _get_embedding(query)
    vec_str = "[" + ",".join(map(str, query_embedding)) + "]"

    conn = get_pg_connection()
    try:
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute(
            """
            SELECT question,
                   answer,
                   1 - (embedding <=> %s::vector) AS similarity
            FROM   dapchatbot
            WHERE  1 - (embedding <=> %s::vector) >= %s
            ORDER  BY embedding <=> %s::vector
            LIMIT  %s
            """,
            (vec_str, vec_str, similarity_threshold, vec_str, k),
        )
        rows = cur.fetchall()
        cur.close()
    finally:
        put_pg_connection(conn)

    docs: List[Document] = []
    for row in rows:
        content = (
            f"Câu hỏi: {row['question']}\n"
            f"Trả lời: {row['answer']}"
        )
        docs.append(
            Document(
                page_content=content,
                metadata={
                    "question": row["question"],
                    "answer": row["answer"],
                    "similarity": float(row["similarity"]),
                },
            )
        )
    return docs

def _normalize_for_match(text: str) -> str:
    """Lowercase, strip punctuation & collapse whitespace for exact matching."""
    text = re.sub(r'[^\w\s]', '', text, flags=re.UNICODE)
    text = re.sub(r'\s+', ' ', text).strip().lower()
    return text


def exact_match_search(question: str):
    normalized = _normalize_for_match(question)
    conn = get_pg_connection()
    try:
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cur.execute(
            """
            SELECT question, answer
            FROM   dapchatbot
            WHERE  LOWER(TRIM(
                     regexp_replace(
                       regexp_replace(question, '[^[:alnum:][:space:]]', '', 'g'),
                       '[[:space:]]+', ' ', 'g'
                     )
                   )) = %s
            LIMIT  1
            """,
            (normalized,)
        )

        row = cur.fetchone()
        cur.close()

        return row

    finally:
        put_pg_connection(conn)


def trigram_search(question: str, threshold: float = 0.45):
    """Find the best match using pg_trgm trigram similarity.

    Returns the top row if similarity >= threshold, else None.
    Requires: CREATE EXTENSION IF NOT EXISTS pg_trgm;
    """
    normalized = _normalize_for_match(question)
    conn = get_pg_connection()
    try:
        cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cur.execute(
            """
            SELECT question,
                   answer,
                   similarity(
                     LOWER(TRIM(
                       regexp_replace(
                         regexp_replace(question, '[^[:alnum:][:space:]]', '', 'g'),
                         '[[:space:]]+', ' ', 'g'
                       )
                     )),
                     %s
                   ) AS sim
            FROM   dapchatbot
            WHERE  similarity(
                     LOWER(TRIM(
                       regexp_replace(
                         regexp_replace(question, '[^[:alnum:][:space:]]', '', 'g'),
                         '[[:space:]]+', ' ', 'g'
                       )
                     )),
                     %s
                   ) >= %s
            ORDER  BY sim DESC
            LIMIT  1
            """,
            (normalized, normalized, threshold),
        )
        row = cur.fetchone()
        cur.close()
        return row
    finally:
        put_pg_connection(conn)


# ---------------------------
# State
# ---------------------------
class AgentState(TypedDict):
    question: str
    intent: Optional[str]
    entities: Optional[List[str]]
    docs: Optional[list]
    rewritten_query: Optional[str]
    relevance: Optional[str]
    topic: Optional[str]
    plan: Optional[List[str]]
    evidence: Optional[List[str]]
    answer: Optional[str]
    verification: Optional[str]


# ---------------------------
# Helpers
# ---------------------------
def safe_json_loads(text: str, default: Dict[str, Any]) -> Dict[str, Any]:
    """Try to extract a JSON object from LLM output (handles markdown fences)."""
    cleaned = text.strip()
    fence_match = re.search(r"```(?:json)?\s*(.*?)```", cleaned, re.DOTALL)
    if fence_match:
        cleaned = fence_match.group(1).strip()
    try:
        data = json.loads(cleaned)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return default


def _docs_context(state: AgentState) -> str:
    """Concatenate page_content of all docs in state."""
    docs = state.get("docs") or []
    return "\n\n".join(d.page_content for d in docs)


# ---------------------------
# Nodes
# ---------------------------
# --- Keyword patterns cho greeting / system_info ---
_GREETING_PATTERNS = re.compile(
    r"^\s*("
    r"xin\s*chào|chào\s*bạn|chào|hello|hi\b|hey\b"
    r"|cảm\s*ơn|cám\s*ơn|thanks|thank\s*you|tks"
    r"|tạm\s*biệt|bye|goodbye|see\s*you"
    r"|ok\b|okay|ừ|ờ|vâng|dạ"
    r"|tốt|hay\s*lắm|giỏi\s*lắm|great|good"
    r")\s*[!.?~]*\s*$",
    re.IGNORECASE,
)

_SYSTEM_INFO_PATTERNS = re.compile(
    r"("
    r"bạn\s*(là|tên)\s*(ai|gì)|tên\s*(của\s*)?bạn"
    r"|you\s*are\s*who|what.*your\s*name"
    r"|mấy\s*giờ|ngày\s*(bao\s*nhiêu|mấy)|hôm\s*nay\s*ngày"
    r"|what\s*time|what.*date|today"
    r"|bạn\s*có\s*thể\s*làm\s*(gì|được\s*gì)"
    r"|bạn\s*làm\s*được\s*gì"
    r"|chức\s*năng"
    r"|bạn\s*(có|biết|giúp)\s*(những?|được)?\s*(gì|gì\s*không)"
    r")",
    re.IGNORECASE,
)


def intent_router(state: AgentState) -> AgentState:
    """
    Routing:
      1. Keyword detection (nhanh, không cần LLM) cho greeting / system_info
      2. Phân luồng theo độ dài (NFC-normalized): >150 ký tự → whitebox, còn lại → RAG
    """
    question = state["question"]
    # NFC normalize để dấu tiếng Việt luôn ở dạng composed (1 codepoint)
    q_stripped = unicodedata.normalize("NFC", question.strip())

    # --- Bước 1: Keyword detection (nhanh, chắc chắn) ---
    if _GREETING_PATTERNS.match(q_stripped):
        return {**state, "intent": "greeting", "entities": []}

    if _SYSTEM_INFO_PATTERNS.search(q_stripped):
        return {**state, "intent": "direct_system_info", "entities": []}

    # --- Bước 2: phân luồng theo độ dài prompt ---
    WHITEBOX_THRESHOLD = 150  # ký tự (NFC)

    if len(q_stripped) > WHITEBOX_THRESHOLD:
        intent = "knowledge_query"   # whitebox pipeline đầy đủ
    else:
        intent = "direct_answer"     # RAG đơn giản

    return {**state, "intent": intent, "entities": []}


def system_info_node(state: AgentState) -> AgentState:
    q = state["question"].strip().lower()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if re.search(r"tên.*bạn|bạn.*tên|bạn\s*là\s*ai|your\s*name|who\s*are", q):
        answer = (
            "Tôi là **ALO** — trợ lý AI chuyên hỗ trợ tra cứu kiến thức. "
            "Bạn có thể hỏi tôi bất cứ điều gì! 😊"
        )
    elif re.search(r"làm\s*(gì|được)|khả\s*năng|chức\s*năng|capabilit|bạn\s*(có|biết|giúp).*gì", q):
        answer = (
            "Tôi có thể giúp bạn:\n"
            "• Tra cứu thông tin từ cơ sở dữ liệu\n"
            "• Trả lời câu hỏi kiến thức\n"
            "• Phân tích và tổng hợp thông tin\n"
            "Hãy hỏi tôi bất cứ điều gì! 😊"
        )
    else:
        answer = f"Bây giờ là {now}. Tôi có thể giúp gì thêm cho bạn?"
    return {**state, "answer": answer}

def exact_match_node(state: AgentState) -> AgentState:

    row = exact_match_search(state["question"])

    if row:
        return {
            **state,
            "answer": row["answer"],
            "intent": "exact_answer"
        }

    return state


def trigram_match_node(state: AgentState) -> AgentState:
    """Tầng 1.5: trigram fuzzy match — bắt lỗi chính tả & biến thể nhỏ."""
    row = trigram_search(state["question"], threshold=0.45)
    if row:
        return {
            **state,
            "answer": row["answer"],
            "intent": "trigram_answer",
        }
    return state


def query_rewriter(state: AgentState) -> AgentState:
    prompt = (
        "Rewrite the following question into a concise Vietnamese search query "
        "suitable for semantic retrieval.  Return ONLY JSON: "
        '{{"rewritten_query": "..."}}\n\n'
        f"Question: {state['question']}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"rewritten_query": state["question"]})
    return {**state, **data}


def rag_lookup(state: AgentState) -> AgentState:
    """Retrieve relevant docs from PostgreSQL via pgvector."""
    query = state.get("rewritten_query") or state["question"]
    docs = pgvector_search(query, k=15, similarity_threshold=0.45)
    return {**state, "docs": docs}


def relevance_judge(state: AgentState) -> AgentState:
    """Deterministic relevance check based on max similarity score (no LLM)."""
    docs = state.get("docs") or []
    if docs:
        max_sim = max(d.metadata.get("similarity", 0) for d in docs)
    else:
        max_sim = 0.0
    relevance = "high" if max_sim >= 0.6 else "low"
    return {**state, "relevance": relevance}


def topic_judge(state: AgentState) -> AgentState:
    prompt = (
        "Classify the topic of this question.\n"
        'Return ONLY JSON: {"topic": "legal"} if it is about Vietnamese law, '
        'or {"topic": "other"} otherwise.\n\n'
        f"Question: {state['question']}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"topic": "other"})
    return {**state, **data}


def answer_draft(state: AgentState) -> AgentState:
    context = _docs_context(state)
    prompt = (
        "Bạn là trợ lý pháp luật Việt Nam. Dựa vào ngữ cảnh được cung cấp, "
        "hãy trả lời câu hỏi một cách ngắn gọn, chính xác bằng tiếng Việt.\n"
        "Nếu ngữ cảnh không đủ, hãy nói rõ rằng bạn không có đủ thông tin.\n\n"
        f"Ngữ cảnh:\n{context}\n\n"
        f"Câu hỏi: {state['question']}"
    )
    resp = llm.invoke(prompt)
    return {**state, "answer": resp.content}


def answer_verifier(state: AgentState) -> AgentState:
    prompt = (
        "Verify whether the answer below is strong, well-supported and accurate.\n"
        'Return ONLY JSON: {"verification": "good"} or {"verification": "weak"}.\n\n'
        f"Question: {state['question']}\nAnswer: {state.get('answer')}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"verification": "weak"})
    return {**state, **data}


def clarify_question(state: AgentState) -> AgentState:
    return {
        **state,
        "answer": "Xin lỗi, tôi chưa chắc chắn về câu trả lời. "
                  "Bạn có thể làm rõ câu hỏi thêm được không?",
    }


def answer_node(state: AgentState) -> AgentState:
    if state.get("answer"):
        return state
    return answer_draft(state)


def greeting_node(state: AgentState) -> AgentState:
    """Phản hồi linh hoạt theo loại greeting."""
    q = state["question"].strip().lower()

    if re.search(r"cảm\s*ơn|cám\s*ơn|thanks|thank", q):
        answer = "Không có gì! 😊 Nếu bạn cần hỏi thêm điều gì, cứ hỏi nhé."
    elif re.search(r"tạm\s*biệt|bye|goodbye", q):
        answer = "Tạm biệt bạn! 👋 Hẹn gặp lại."
    elif re.search(r"ok\b|okay|ừ|ờ|vâng|dạ", q):
        answer = "Vâng! Bạn cần hỏi thêm gì không? 😊"
    elif re.search(r"tốt|hay\s*lắm|giỏi|great|good", q):
        answer = "Cảm ơn bạn! 😄 Tôi luôn sẵn sàng hỗ trợ."
    else:
        answer = "Xin chào! 👋 Tôi là trợ lý DAP — có thể giúp gì cho bạn?"

    return {**state, "answer": answer}


def direct_answer_node(state: AgentState) -> AgentState:
    """Simple RAG-based answer: retrieve docs and respond directly."""
    query = state.get("rewritten_query") or state["question"]
    docs = pgvector_search(query, k=15, similarity_threshold=0.45)
    n_found = len(docs)
    context = "\n\n".join(
        f"[{i+1}/{n_found}] {d.page_content}" for i, d in enumerate(docs)
    )
    prompt = (
        "Bạn là trợ lý thông minh. Dưới đây là TẤT CẢ các thông tin liên quan "
        f"tìm được từ cơ sở dữ liệu ({n_found} kết quả).\n"
        "Hãy TỔNG HỢP tất cả thông tin từ các nguồn liên quan và trả lời "
        "một cách đầy đủ, có cấu trúc bằng tiếng Việt.\n"
        "Nếu có nhiều khía cạnh khác nhau, hãy trình bày từng khía cạnh rõ ràng.\n"
        "Nếu ngữ cảnh không đủ, hãy nói rõ rằng bạn không có đủ thông tin.\n\n"
        f"Ngữ cảnh:\n{context}\n\n"
        f"Câu hỏi: {state['question']}"
    )
    resp = llm.invoke(prompt)
    return {**state, "docs": docs, "answer": resp.content}


def direct_query_rewriter(state: AgentState) -> AgentState:
    """Lightweight query rewriter for the direct_answer path."""
    prompt = (
        "Viết lại câu hỏi sau thành một truy vấn tìm kiếm ngắn gọn bằng tiếng Việt, "
        "tối ưu cho việc tìm kiếm semantic trong cơ sở dữ liệu pháp luật.\n"
        "Giữ nguyên các thuật ngữ pháp lý quan trọng. "
        'Trả về CHỈ JSON: {{"rewritten_query": "..."}}\n\n'
        f"Câu hỏi: {state['question']}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"rewritten_query": state["question"]})
    return {**state, **data}


# ---------------------------
# Evidence Subgraph
# ---------------------------
def search_planner(state: AgentState) -> AgentState:
    prompt = (
        "Plan a short retrieval strategy for answering this legal question.\n"
        'Return ONLY JSON: {"plan": ["step1", "step2", ...]}.\n\n'
        f"Question: {state['question']}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"plan": []})
    return {**state, **data}


def multi_source_retrieval(state: AgentState) -> AgentState:
    """Retrieve docs using plan steps as additional queries, merging unique results."""
    plan = state.get("plan") or []
    all_docs: List[Document] = list(state.get("docs") or [])
    seen = {d.metadata.get("question", "") for d in all_docs}

    # Build query list: original question + each plan step
    queries = [state["question"]] + [s for s in plan if isinstance(s, str)]

    for query in queries:
        new_docs = pgvector_search(query, k=10, similarity_threshold=0.40)
        for d in new_docs:
            q = d.metadata.get("question", "")
            if q not in seen:
                seen.add(q)
                all_docs.append(d)

    return {**state, "docs": all_docs}


def source_ranker(state: AgentState) -> AgentState:
    """Sort docs by similarity."""
    docs = state.get("docs") or []
    docs.sort(key=lambda d: d.metadata.get("similarity", 0), reverse=True)
    return {**state, "docs": docs}


def evidence_extractor(state: AgentState) -> AgentState:
    context = _docs_context(state)
    prompt = (
        "Extract the key evidence snippets from the context below.\n"
        'Return ONLY JSON: {"evidence": ["snippet1", "snippet2", ...]}.\n\n'
        f"Context:\n{context}"
    )
    resp = llm.invoke(prompt)
    data = safe_json_loads(resp.content, {"evidence": []})
    return {**state, **data}


def conclusion_builder(state: AgentState) -> AgentState:
    """Tổng hợp evidence, đưa ra kết luận VÀ tự kiểm chứng (gộp claim_verifier)."""
    evidence = "\n".join(state.get("evidence") or [])
    prompt = (
        "Bạn là trợ lý pháp luật Việt Nam. Hãy thực hiện 2 bước:\n"
        "1. Kiểm chứng các bằng chứng: loại bỏ thông tin mâu thuẫn hoặc không đáng tin.\n"
        "2. Tổng hợp bằng chứng đáng tin và đưa ra câu trả lời chính xác bằng tiếng Việt.\n\n"
        f"Bằng chứng:\n{evidence}\n\n"
        f"Câu hỏi: {state['question']}"
    )
    resp = llm.invoke(prompt)
    return {**state, "answer": resp.content}


# ---------------------------
# Routing functions
# ---------------------------
def route_intent(state: AgentState):
    return state.get("intent", "knowledge_query")


def route_topic(state: AgentState):
    return state.get("topic", "other")


def route_verification(state: AgentState):
    return state.get("verification", "weak")

def route_exact(state: AgentState):
    """Check intent set by exact_match_node, not just answer existence."""
    if state.get("intent") == "exact_answer":
        return "found"
    return "not_found"


def route_trigram(state: AgentState):
    """Check intent set by trigram_match_node."""
    if state.get("intent") == "trigram_answer":
        return "found"
    return "not_found"


# ---------------------------
# Build LangGraph
# ---------------------------
graph = StateGraph(AgentState)

graph.add_node("router",           intent_router)
graph.add_node("system_info",      system_info_node)
graph.add_node("query_rewriter",   query_rewriter)
graph.add_node("rag",              rag_lookup)
graph.add_node("relevance_judge",  relevance_judge)
graph.add_node("topic_judge",      topic_judge)
graph.add_node("answer_draft",     answer_draft)
graph.add_node("answer_verifier",  answer_verifier)
graph.add_node("clarify_question", clarify_question)
graph.add_node("answer",           answer_node)
graph.add_node("greeting",         greeting_node)
graph.add_node("direct_answer",         direct_answer_node)
graph.add_node("direct_query_rewriter", direct_query_rewriter)
graph.add_node("exact_match",           exact_match_node)
graph.add_node("trigram_match",         trigram_match_node)

graph.add_node("search_planner",          search_planner)
graph.add_node("multi_source_retrieval",  multi_source_retrieval)
graph.add_node("source_ranker",           source_ranker)
graph.add_node("evidence_extractor",      evidence_extractor)
graph.add_node("conclusion_builder",      conclusion_builder)

graph.set_entry_point("router")

graph.add_conditional_edges("router", route_intent, {
    "greeting":           "greeting",
    "direct_system_info": "system_info",
    "direct_answer":      "exact_match",
    "knowledge_query":    "query_rewriter",
})

graph.add_conditional_edges("exact_match", route_exact, {
    "found":     "answer",
    "not_found": "trigram_match",
})

graph.add_conditional_edges("trigram_match", route_trigram, {
    "found":     "answer",
    "not_found": "direct_query_rewriter",
})

graph.add_edge("direct_query_rewriter", "direct_answer")

graph.add_edge("system_info",    "answer")
graph.add_edge("query_rewriter", "rag")
graph.add_edge("rag",            "relevance_judge")
graph.add_edge("relevance_judge", "topic_judge")

graph.add_conditional_edges("topic_judge", route_topic, {
    "legal": "search_planner",
    "other": "answer_draft",
})

graph.add_edge("search_planner",         "multi_source_retrieval")
graph.add_edge("multi_source_retrieval",  "source_ranker")
graph.add_edge("source_ranker",           "evidence_extractor")
graph.add_edge("evidence_extractor",      "conclusion_builder")
graph.add_edge("conclusion_builder",      "answer_verifier")

graph.add_edge("answer_draft", "answer_verifier")

graph.add_conditional_edges("answer_verifier", route_verification, {
    "weak": "clarify_question",
    "good": "answer",
})

graph.add_edge("clarify_question", END)
graph.add_edge("greeting",        END)
graph.add_edge("direct_answer",   END)
graph.add_edge("answer",          END)

app = graph.compile()

# ---------------------------
# Interactive run loop
# ---------------------------
if __name__ == "__main__":
    print("=" * 60)
    print("  LangGraph Agent  –  LM Studio + pgvector RAG")
    print("  DB: PostgreSQL @ %s:%s/%s" % (PG_HOST, PG_PORT, PG_DB))
    print("  LLM: %s @ %s" % (LMSTUDIO_MODEL, LMSTUDIO_BASE_URL))
    print("=" * 60)

    if not test_pg_connection():
        print(
            "\n⚠️  Could not verify the 'dapchatbot' table.\n"
            "    Make sure Docker is running (docker compose up -d)\n"
            "    and embeddings/embedd.py has been executed.\n"
        )

    print("\nType your question (or 'exit' to quit):\n")

    while True:
        try:
            q = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not q or q.lower() in ("exit", "quit"):
            break

        try:
            out = app.invoke({"question": q})
            print("\nAgent:", out.get("answer", "(no answer)"), "\n")
        except Exception as exc:
            print(f"\n❌ Error: {exc}\n")
